package com.lpx.limiting_surface;


import com.lpx.Elevator_IF.Elevator_Service;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

import static java.lang.Thread.sleep;

public class View_Logic extends JFrame {
    private JTextField show01,show02;
    private JPanel jPanel;
    private int floor=1;
    private boolean flag=true;
    JButton jButton[] =new JButton[14];
    double weight=0;
    private double floorWeight=500;
    //总楼层
    private int storey=12;
    //运行楼层集合
    public List<Integer> list=new ArrayList<Integer>();

    public void init() {
       init_v();
    }

    //窗体设置
    public void init_v() {
        //文本框
        show01=new JTextField("当前楼层:"+floor);
        show01.setFont(new Font("fangsong",Font.BOLD,18));
        show01.setBackground(Color.WHITE);
        // add(show, BorderLayout.NORTH);
        show01.setBounds(20,15,200,80);
        add(show01);

        show02=new JTextField("输入楼层:");
        show02.setFont(new Font("fangsong",Font.BOLD,18));
        show02.setBackground(Color.WHITE);
        add(show02);
        show02.setBounds(20,110,200,80);

        //清空布局管理器
        this.setLayout(null);
        //网格布局
        jPanel=new JPanel();
        jPanel.setBounds(20,200,200,500);
        this.add(jPanel);
        GridLayout gridLayout = new GridLayout(7,2,60,3);

        ApplicationContext ac = new ClassPathXmlApplicationContext("mySpring.xml");
        Elevator_Service service = (Elevator_Service) ac.getBean("service");

        for(int i=0;i<=jButton.length;i++){
            int q=i+1;
            if (i<=11){
                jButton[i] =new JButton(String.valueOf(q));
                jPanel.add(jButton[i]);
                int finalI = i;
                //为按钮创建监听器
                jButton[i].addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        jButton[finalI].setBackground(Color.cyan);
                        list.add(q);
                        weight=weight+service.weightadd();
                        System.out.println(String.format("当前重量"+"%.2f", weight)+"KG");
                        show02.setText(String.valueOf(list));
                        if(list.get(list.size()-1)<=floor) {

                            flag = false;
                        }else if(list.get(list.size()-1)>=floor) {

                            flag = true;
                        }
                    }
                });
            }else if (i==12){
                jButton[i] =new JButton("<>");
                jPanel.add(jButton[i]);
                jButton[i].addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                            show01.setText("请求开门...");
                    }
                });
            }else if(i==13) {
                jButton[i] =new JButton("><");
                jPanel.add(jButton[i]);
                jButton[i].addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        //排序
                        //

                        service.listSort(list);
                        show02.setText(String.valueOf(list));
                        show01.setText("关门...");
                        if (weight <= floorWeight){
                            if (list.size() > 0) {
                                if (flag == true) {
                                    for (int m = floor; m <= storey; m++) {

                                        // show01.setText("当前到达楼层"+m);
                                        System.out.println("当前楼层" + m);
                                        try {
                                            sleep(1000);
                                            // jButton[m-1].setBackground(Color.white);
                                        } catch (InterruptedException e1) {
                                            e1.printStackTrace();
                                        }

                                        System.out.println(". . . . . .");
                                        for (int n = 0; n < list.size(); n++) {
                                            if (m == list.get(n)) {
                                                weight = service.weightcut(weight);
//                                                if (weight<0){
//                                                    System.out.println("当前重量"+0.00+"KG");
//                                                }
                                                if (weight > 0 && m != list.get(list.size() - 1)) {
                                                    System.out.println(String.format("当前重量" + "%.2f", weight) + "KG");
                                                }
                                                jButton[m - 1].setBackground(null);
                                                show01.setText("开门-当前楼层为" + list.get(n));
                                                JOptionPane.showMessageDialog(null, "到达楼层：" + m + "-开门", "标题", JOptionPane.PLAIN_MESSAGE);
                                                if (m == list.get(list.size() - 1)) {
                                                    jButton[m - 1].setBackground(null);
                                                    show01.setText("开门-当前楼层为" + list.get(n));
                                                    weight = 0;
                                                    System.out.println("当前重量" + 0.00 + "KG");
                                                    list.clear();
                                                    floor = m;
                                                    flag = true;
                                                    try {
                                                        sleep(2000);
                                                    } catch (InterruptedException e1) {
                                                        e1.printStackTrace();
                                                    }
                                                    show01.setText("当前电梯在第：" + floor + " 层");
                                                    show02.setText("当前电梯空");
                                                    return;
                                                }
                                                break;
                                            }

                                        }
                                    }
                                } else {
                                    for (int m = floor; m >= 1; m--) {

                                        // show01.setText("当前到达楼层"+m);
                                        try {
                                            sleep(1000);
                                            // jButton[m-1].setBackground(Color.white);
                                        } catch (InterruptedException e1) {
                                            e1.printStackTrace();
                                        }
                                        System.out.println(". . . . . .");
                                        System.out.println("当前楼层" + m);
                                        for (int n = list.size() - 1; n >= 0; n--) {
                                            if (m == list.get(n)) {
                                                weight = service.weightcut(weight);

                                                if (weight > 0 && m != list.get(0)) {
                                                    System.out.println(String.format("当前重量" + "%.2f", weight) + "KG");
                                                }

                                                jButton[m - 1].setBackground(null);
                                                show01.setText("开门-当前楼层为" + list.get(n));
                                                JOptionPane.showMessageDialog(null, "到达楼层：" + m + "-开门", "标题", JOptionPane.PLAIN_MESSAGE);

                                                if (m == list.get(0)) {
                                                    jButton[m - 1].setBackground(null);
                                                    show01.setText("开门-当前楼层为" + list.get(n));
                                                    weight = 0;
                                                    System.out.println("当前重量" + 0.00 + "KG");
                                                    list.clear();
                                                    floor = m;
                                                    flag = true;
                                                    try {
                                                        sleep(2000);
                                                    } catch (InterruptedException e1) {
                                                        e1.printStackTrace();
                                                    }
                                                    show01.setText("当前电梯在第：" + floor + " 层");
                                                    show02.setText("当前电梯空");
                                                    return;
                                                }
                                                break;
                                            }

                                        }
                                    }
                                }
                            } else {
                                show01.setText("未输入楼层！");
                            }
                        }else {
                            show01.setText("电梯超重！");
                            list.clear();
                            for (int i=0;i<=11;i++){
                                jButton[i].setBackground(null);
                            }
                            weight=0;
                            return;
                        }
                    }
                });
            }
            jPanel.setLayout(gridLayout);
        }
        //设置边框
        jPanel.setBorder(BorderFactory.createTitledBorder("按键"));
        //窗口
        this.setTitle("电梯系统");
        // this.setSize(300, 700);
        this.setBounds(800,80,250,760);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setVisible(true);

        //设置窗体大小是否可变
        this.setResizable(false);

    }
}
package com.lpx.Elevator_IF;

import java.util.List;

/**
 * company: www.abc.com
 * Author: Administrator
 * Create Data: 2020/11/14 0014
 */
public interface Elevator_Service {
    //正序排序
    public List listSort(List list);

    //倒序排序
    // public List listSort01(List list);

    //随机数
    // public int random(int i);

    //体重增
    public double weightadd();

    //体重减
    public double weightcut(double weight);
}
